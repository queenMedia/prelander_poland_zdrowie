This is the image of 

[[image_celebrity_3]][ ]
 