import{S as e,i as t,s as n}from"../chunks/index.c4c755d4.js";class l extends e{constructor(s){super(),t(this,s,null,null,n,{})}}export{l as component};
